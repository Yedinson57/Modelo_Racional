-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Biblioteca;
-- voy a usar la base de datos creada
USE Biblioteca;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Usuario
CREATE TABLE Usuario (
  Cod_Usuario INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Direccion VARCHAR(100)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Libro
CREATE TABLE Libro (
  Cod_Libro INT PRIMARY KEY,
  Titulo VARCHAR(100),
  Autor VARCHAR(80),
  Anio_Publicacion INT
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Prestamo (entidad dependiente)
CREATE TABLE Prestamo (
  Cod_Prestamo INT PRIMARY KEY,
  Fecha_Prestamo DATE,
  Fecha_Devolucion DATE,
  Cod_Usuario INT,
  Cod_Libro INT,
  FOREIGN KEY (Cod_Usuario) REFERENCES Usuario(Cod_Usuario),
  FOREIGN KEY (Cod_Libro) REFERENCES Libro(Cod_Libro)
);
