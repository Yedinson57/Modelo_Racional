-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Universidad;
-- voy a usar la base de datos creada
USE Universidad;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Profesor
CREATE TABLE Profesor (
  Cod_Profesor INT PRIMARY KEY,
  Nombre VARCHAR(50),
  Especialidad VARCHAR(50)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Curso
CREATE TABLE Curso (
  Cod_Curso INT PRIMARY KEY,
  Nombre_Curso VARCHAR(100),
  Creditos INT,
  Cod_Profesor INT,
  FOREIGN KEY (Cod_Profesor) REFERENCES Profesor(Cod_Profesor)
);

-- ahora creo la tercer tabla independiente a partir del modelo MER
-- Tabla Estudiante
CREATE TABLE Estudiante (
  Num_Matricula INT PRIMARY KEY,
  Nombre VARCHAR(50),
  Correo VARCHAR(80)
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Inscripcion (entidad dependiente de N:M)
CREATE TABLE Inscripcion (
  Cod_Inscripcion INT PRIMARY KEY,
  Fecha_Inscripcion DATE,
  Nota DECIMAL(4,2),
  Num_Matricula INT,
  Cod_Curso INT,
  FOREIGN KEY (Num_Matricula) REFERENCES Estudiante(Num_Matricula),
  FOREIGN KEY (Cod_Curso) REFERENCES Curso(Cod_Curso)
);