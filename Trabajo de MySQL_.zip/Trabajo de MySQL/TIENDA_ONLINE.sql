-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Tienda_Online;
-- voy a usar la base de datos creada
USE Tienda_Online;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Cliente
CREATE TABLE Cliente (
  Cod_Cliente INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Direccion VARCHAR(100)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Producto
CREATE TABLE Producto (
  Cod_Producto INT PRIMARY KEY,
  Nombre VARCHAR(80),
  Precio DECIMAL(10,2)
);

-- ahora creo la tercer tabla independiente a partir del modelo MER
-- Tabla Pedido
CREATE TABLE Pedido (
  Cod_Pedido INT PRIMARY KEY,
  Fecha DATE,
  Cod_Cliente INT,
  FOREIGN KEY (Cod_Cliente) REFERENCES Cliente(Cod_Cliente)
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Detalle_Pedido (entidad dependiente N:M)
CREATE TABLE Detalle_Pedido (
  Cod_Pedido INT,
  Cod_Producto INT,
  Cantidad INT,
  PRIMARY KEY (Cod_Pedido, Cod_Producto),
  FOREIGN KEY (Cod_Pedido) REFERENCES Pedido(Cod_Pedido),
  FOREIGN KEY (Cod_Producto) REFERENCES Producto(Cod_Producto)
);
