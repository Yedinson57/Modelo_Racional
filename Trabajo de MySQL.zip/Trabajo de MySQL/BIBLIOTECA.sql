-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Biblioteca;
-- voy a usar la base de datos creada
USE Biblioteca;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Usuario
CREATE TABLE IF NOT EXISTS Usuario (
  Cod_Usuario INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Direccion VARCHAR(100)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Libro
CREATE TABLE IF NOT EXISTS Libro (
  Cod_Libro INT PRIMARY KEY,
  Titulo VARCHAR(100),
  Autor VARCHAR(80),
  Anio_Publicacion INT
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Prestamo (entidad dependiente)
CREATE TABLE IF NOT EXISTS Prestamo (
  Cod_Prestamo INT PRIMARY KEY,
  Fecha_Prestamo DATE,
  Fecha_Devolucion DATE,
  Cod_Usuario INT,
  Cod_Libro INT,
  FOREIGN KEY (Cod_Usuario) REFERENCES Usuario(Cod_Usuario),
  FOREIGN KEY (Cod_Libro) REFERENCES Libro(Cod_Libro)
);
-- voy a crear la data para la base de datos Biblioteca  
-- Insertar datos en la tabla Usuario
INSERT INTO Usuario (Cod_Usuario, Nombre, Direccion) VALUES
(1, "Juan López", "Calle 10 #8-25"),
(2, "Sara Ruiz","'Carrera 5 #20-10"),
(3, "Andrés Gómez", "Calle 8 #4-22"),
(4, "Paula Ortiz", "Carrera 11 #6-55");

-- Insertar datos en la tabla Libro
INSERT INTO Libro (Cod_Libro, Titulo, Autor, Anio_Publicacion) VALUES
(10, "Cien años de soledad", "Gabriel García Márquez", 1967),
(11, "El Principito", "Antoine de Saint-Exupéry", 1943),
(12, "Rayuela", "Julio Cortázar", 1963),
(13, "La Odisea", "Homero", -700);

-- Insertar datos en la tabla Préstamo
INSERT INTO Prestamo (Cod_Prestamo, Fecha_Prestamo, Fecha_Devolucion, Cod_Usuario, Cod_Libro) VALUES
(100, "2025-03-01", "2025-03-10", 1, 10),
(101, "2025-03-02", "2025-03-12", 2, 11),
(102, "2025-03-03", "2025-03-13", 3, 12),
(103, "2025-03-05", "2025-03-15", 4, 13);

-- Consultas de la DATA REGISTRADA
SELECT u.Nombre AS Usuario, l.Titulo AS Libro, p.Fecha_Prestamo, p.Fecha_Devolucion
FROM Prestamo p
JOIN Usuario u ON p.Cod_Usuario = u.Cod_Usuario
JOIN Libro l ON p.Cod_Libro = l.Cod_Libro;


