-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Universidad;
-- voy a usar la base de datos creada
USE Universidad;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Profesor
CREATE TABLE IF NOT EXISTS Profesor (
  Cod_Profesor INT PRIMARY KEY,
  Nombre VARCHAR(50),
  Especialidad VARCHAR(50)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Curso
CREATE TABLE IF NOT EXISTS Curso (
  Cod_Curso INT PRIMARY KEY,
  Nombre_Curso VARCHAR(100),
  Creditos INT,
  Cod_Profesor INT,
  FOREIGN KEY (Cod_Profesor) REFERENCES Profesor(Cod_Profesor)
);

-- ahora creo la tercer tabla independiente a partir del modelo MER
-- Tabla Estudiante
CREATE TABLE IF NOT EXISTS Estudiante (
  Num_Matricula INT PRIMARY KEY,
  Nombre VARCHAR(50),
  Correo VARCHAR(80)
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Inscripcion (entidad dependiente de N:M)
CREATE TABLE IF NOT EXISTS Inscripcion (
  Cod_Inscripcion INT PRIMARY KEY,
  Fecha_Inscripcion DATE,
  Nota DECIMAL(4,2),
  Num_Matricula INT,
  Cod_Curso INT,
  FOREIGN KEY (Num_Matricula) REFERENCES Estudiante(Num_Matricula),
  FOREIGN KEY (Cod_Curso) REFERENCES Curso(Cod_Curso)
);

-- voy a crear la data para la base de datos Universidad 
-- Insertar datos en la tabla Profesor
INSERT INTO Profesor (Cod_Profesor, Nombre, Especialidad) VALUES
(1, "Ana", "Matemáticas"),
(2, "Carlos", "Programación"),
(3, "María", "Física"),
(4, "Pedro", "Estadística");

-- Insertar datos en la tabla Curso
INSERT INTO Curso (Cod_Curso, Nombre_Curso, Creditos, Cod_Profesor) VALUES
(101, "Cálculo I", 3, 1),
(102, "Programación Básica", 4, 2),
(103, "Física I", 3, 3),
(104, "Estadística", 2, 4);

-- Insertar datos en la tabla Estudiante
INSERT INTO Estudiante (Num_Matricula, Nombre, Correo) VALUES
(2001, "Luis Pérez", "luisp@mail.com"),
(2002, "María Gómez", "mariag@mail.com"),
(2003, "Julián Ríos", "julianr@mail.com"),
(2004, "Camila Torres", "camila@mail.com");

-- Insertar datos en la tabla Inscripción
INSERT INTO Inscripcion (Cod_Inscripcion, Fecha_Inscripcion, Nota, Num_Matricula, Cod_Curso) VALUES
(1, "2025-02-10", 4.5, 2001, 101),
(2, "2025-02-11", 3.8, 2002, 102),
(3, "2025-02-12", 4.0, 2003, 103),
(4, "2025-02-15", 3.5, 2004, 104);

-- Consultas de la DATA REGISTRADA
SELECT e.Nombre AS Estudiante, c.Nombre_Curso, p.Nombre AS Profesor, i.Nota
FROM Inscripcion i
JOIN Estudiante e ON i.Num_Matricula = e.Num_Matricula
JOIN Curso c ON i.Cod_Curso = c.Cod_Curso
JOIN Profesor p ON c.Cod_Profesor = p.Cod_Profesor;
