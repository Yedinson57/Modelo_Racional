-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Tienda_Online;
-- voy a usar la base de datos creada
USE Tienda_Online;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Cliente
CREATE TABLE IF NOT EXISTS Cliente (
  Cod_Cliente INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Direccion VARCHAR(100)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Producto
CREATE TABLE IF NOT EXISTS Producto (
  Cod_Producto INT PRIMARY KEY,
  Nombre VARCHAR(80),
  Precio DECIMAL(10,2)
);

-- ahora creo la tercer tabla independiente a partir del modelo MER
-- Tabla Pedido
CREATE TABLE IF NOT EXISTS Pedido (
  Cod_Pedido INT PRIMARY KEY,
  Fecha DATE,
  Cod_Cliente INT,
  FOREIGN KEY (Cod_Cliente) REFERENCES Cliente(Cod_Cliente)
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Detalle_Pedido (entidad dependiente N:M)
CREATE TABLE IF NOT EXISTS Detalle_Pedido (
  Cod_Pedido INT,
  Cod_Producto INT,
  Cantidad INT,
  PRIMARY KEY (Cod_Pedido, Cod_Producto),
  FOREIGN KEY (Cod_Pedido) REFERENCES Pedido(Cod_Pedido),
  FOREIGN KEY (Cod_Producto) REFERENCES Producto(Cod_Producto)
);
-- voy a crear la data para la base de datos Tienda_Online
-- Insertar datos en la tabla Cliente
INSERT INTO Cliente (Cod_Cliente, Nombre, Direccion) VALUES
(1, "Pedro Salazar", "Av. Siempre Viva 123"),
(2, "Luisa Ramos", "Calle 7 #8-45"),
(3, "Sofía Morales", "Carrera 10 #20-30"),
(4, "Camilo Duarte", "Calle 5 #12-60");

-- Insertar datos en la tabla Producto
INSERT INTO Producto (Cod_Producto, Nombre, Precio) VALUES
(101, "Teclado", 85000),
(102, "Mouse", 45000),
(103, "Monitor", 500000),
(104, "Memoria USB", 25000);

-- Insertar datos en la tabla Pedido
INSERT INTO Pedido (Cod_Pedido, Fecha, Cod_Cliente) VALUES
(201, "2025-05-05", 1),
(202, "2025-05-06", 2),
(203, "2025-05-07", 3),
(204, "2025-05-08", 4);

-- Insertar datos en la tabla Detalle_Pedido
INSERT INTO Detalle_Pedido (Cod_Pedido, Cod_Producto, Cantidad) VALUES
(201, 101, 2),
(201, 103, 1),
(202, 102, 3),
(203, 104, 5),
(204, 101, 1),
(204, 102, 2);

-- Consultas de la DATA REGISTRADA
SELECT c.Nombre AS Cliente, p.Cod_Pedido, pr.Nombre AS Producto, pr.Precio, d.Cantidad,
       (pr.Precio * d.Cantidad) AS Total_Producto
FROM Pedido p
JOIN Cliente c ON p.Cod_Cliente = c.Cod_Cliente
JOIN Detalle_Pedido d ON p.Cod_Pedido = d.Cod_Pedido
JOIN Producto pr ON d.Cod_Producto = pr.Cod_Producto;
