-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Hospital;
-- voy a usar la base de datos creada
USE Hospital;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Paciente
CREATE TABLE Paciente (
  Cod_Paciente INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Direccion VARCHAR(100),
  Telefono VARCHAR(20)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Medico
CREATE TABLE Medico (
  Cod_Medico INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Especialidad VARCHAR(60)
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Consulta (entidad dependiente)
CREATE TABLE Citas (
  Cod_Citas INT PRIMARY KEY,
  Fecha DATE,
  Diagnostico VARCHAR(150),
  Cod_Paciente INT,
  Cod_Medico INT,
  FOREIGN KEY (Cod_Paciente) REFERENCES Paciente(Cod_Paciente),
  FOREIGN KEY (Cod_Medico) REFERENCES Medico(Cod_Medico)
);

