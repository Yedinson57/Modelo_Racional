-- Vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS Hospital;
-- voy a usar la base de datos creada
USE Hospital;

-- creamos la primer tabla independiente para la primer entidad independiente del modelo MER
-- Tabla Paciente
CREATE TABLE IF NOT EXISTS Paciente (
  Cod_Paciente INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Direccion VARCHAR(100),
  Telefono VARCHAR(20)
);

-- ahora creo la segunda tabla independiente a partir del modelo MER
-- Tabla Medico
CREATE TABLE IF NOT EXISTS Medico (
  Cod_Medico INT PRIMARY KEY,
  Nombre VARCHAR(60),
  Especialidad VARCHAR(60)
);

-- creamos la tercer tabla, dependiente, a aprtir del modelo MER
-- Tabla Consulta (entidad dependiente)
CREATE TABLE IF NOT EXISTS Citas (
  Cod_Citas INT PRIMARY KEY,
  Fecha DATE,
  Diagnostico VARCHAR(150),
  Cod_Paciente INT,
  Cod_Medico INT,
  FOREIGN KEY (Cod_Paciente) REFERENCES Paciente(Cod_Paciente),
  FOREIGN KEY (Cod_Medico) REFERENCES Medico(Cod_Medico)
);
-- voy a crear la data para la base de datos Hospital 
-- Insertar datos en la tabla Paciente
INSERT INTO Paciente (Cod_Paciente, Nombre, Direccion, Telefono) VALUES
(1, "Carlos Medina", "Calle 12 #3-45", "3105551234"),
(2, "Laura Rojas", "Carrera 9 #10-22", "3204449876"),
(3, "Marcos Díaz", "Calle 4 #6-70", "3113332222"),
(4, "Julia Serrano", "Carrera 8 #5-30", "3007776666");

-- Insertar datos en la tabla Médico
INSERT INTO Medico (Cod_Medico, Nombre, Especialidad) VALUES
(10, "Dr. Gómez", "Pediatría"),
(11, "Dra. Torres", "Cardiología"),
(12, "Dr. Ruiz", "Neurología"),
(13, "Dra. Silva", "Dermatología");

-- Insertar datos en la tabla Consulta
INSERT INTO Citas (Cod_Citas, Fecha, Diagnostico, Cod_Paciente, Cod_Medico) VALUES
(1000, "2025-04-15", "Resfriado común", 1, 10),
(1001, "2025-04-16", "Chequeo cardíaco", 2, 11),
(1002, "2025-04-17", "Dolor de cabeza", 3, 12),
(1003, "2025-04-18", "Alergia cutánea", 4, 13);

-- Consultas de la DATA REGISTRADA
SELECT pa.Nombre AS Paciente, m.Nombre AS Medico, m.Especialidad, c.Diagnostico, c.Fecha
FROM Citas c
JOIN Paciente pa ON c.Cod_Paciente = pa.Cod_Paciente
JOIN Medico m ON c.Cod_Medico = m.Cod_Medico;

